<?php $__env->startSection('title', 'Проверка сайта'); ?>
<?php $__env->startSection('content'); ?>
<div style="margin: 0;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);">
    <div class="well well bs-component">
        <form class="form-horizontal" method="post">
            <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
            <fieldset>
                <legend>Введите сайт для проверки</legend>
                <div class="form-group">
                    <div>
                        <input type="text" class="form-control" id="url" placeholder="Сайт" name="url">
                    </div>
                </div>
                <div class="form-group">
                    <div>
                        <button type="submit" class="btn btn-primary">Проверить</button>
                    </div>
                </div>
            </fieldset>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>